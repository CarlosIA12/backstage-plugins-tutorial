import json
import os
import requests

def lambda_handler(event, context):

    # Define the Vault API endpoint and headers
    vault_url = os.environ.get('VAULT_URL')
    vault_token = os.environ.get('VAULT_TOKEN')
    vault_namespace = "admin"
    
    headers = {
        "X-Vault-Token": vault_token,
        "X-Vault-Namespace": vault_namespace,
    }
    
    # Define the path to the secret
    secret_path = "/v1/secret/data/backstage-plugins-tutorial"
    
    # Make the HTTP GET request to Vault
    response = requests.get(vault_url + secret_path, headers=headers)
    
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the JSON response
        data = response.json()
    
        # Extract the "data" field
        secret_data = data.get("data")
    
        if secret_data:
            # Print or process the secret data here
            print(json.dumps(secret_data, indent=4))
        else:
            print("Secret data not found.")
    else:
        print("Error: Request to Vault failed with status code", response.status_code)
